+++
title = "Test 1"
tags = ["test"]
date = "1012-01-01"
+++

Test 1
I am referencing a footnote[^1]


[^1]: I am the footnote
